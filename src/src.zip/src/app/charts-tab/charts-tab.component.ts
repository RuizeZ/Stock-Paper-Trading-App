import { Component, OnInit, Input } from '@angular/core';
import * as Highcharts from 'highcharts/highstock';
import IndicatorsCore from "highcharts/indicators/indicators";
import IndicatorVBP from "highcharts/indicators/volume-by-price";
IndicatorsCore(Highcharts);
IndicatorVBP(Highcharts);

@Component({
  selector: 'app-charts-tab',
  templateUrl: './charts-tab.component.html',
  styleUrls: ['./charts-tab.component.css']
})
export class ChartsTabComponent implements OnInit {
  @Input() searchData!: any;
  Highcharts: typeof Highcharts = Highcharts;
  chartConstructor: string = 'chart';
  chartOptions: Highcharts.Options = {};
  chartDate!: number[]
  chartPrice!: number[]
  chartColor !: string;
  priceArr: any[] = []
  candleStickArr: any[] = [];
  volumeArr: any[] = [];
  constructor() { }

  ngOnInit(): void {
    if (this.searchData['history']['s'] != 'no_data') {
      // create the chart
      // candlestick array
      this.chartDate = this.searchData['history-charts']['t'];
      this.chartPrice = this.searchData['history-charts']['c'];

      for (let i = 0; i < this.chartDate.length; i++) {
        this.candleStickArr.push([this.chartDate[i] * 1000, this.searchData['history-charts']['o'][i],
        this.searchData['history-charts']['h'][i],
        this.searchData['history-charts']['l'][i],
        this.chartPrice[i]
        ]);
        this.volumeArr.push([this.chartDate[i] * 1000, this.searchData['history-charts']['v'][i]])
        this.priceArr.push([this.chartDate[i] * 1000, this.chartPrice[i]]);
      }
      this.chartOptions = {
        rangeSelector: {
          selected: 2
        },

        title: {
          text: this.searchData['company']['ticker'] + ' Historical'
        },

        subtitle: {
          text: 'With SMA and Volume by Price technical indicators'
        },

        yAxis: [{
          startOnTick: false,
          endOnTick: false,
          labels: {
            align: 'right',
            x: -3
          },
          title: {
            text: 'OHLC'
          },
          height: '60%',
          lineWidth: 2,
          resize: {
            enabled: true
          }
        }, {
          labels: {
            align: 'right',
            x: -3
          },
          title: {
            text: 'Volume'
          },
          top: '65%',
          height: '35%',
          offset: 0,
          lineWidth: 2
        }],

        tooltip: {
          split: true
        },

        plotOptions: {
          // series: {
          //   dataGrouping: {
          //     units: groupingUnits
          //   }
          // }
        },

        series: [{
          type: 'candlestick',
          name: this.searchData['company']['ticker'],
          id: 'candlestick',
          zIndex: 2,
          data: this.candleStickArr
        }, {
          type: 'column',
          name: 'Volume',
          id: 'volume',
          data: this.volumeArr,
          yAxis: 1
        }, {
          type: 'vbp',
          linkedTo: 'candlestick',
          params: {
            volumeSeriesID: 'volume'
          },
          dataLabels: {
            enabled: false
          },
          zoneLines: {
            enabled: false
          }
        }, {
          type: 'sma',
          linkedTo: 'candlestick',
          zIndex: 1,
          marker: {
            enabled: false
          }
        }]
      }
    }
  }

}
