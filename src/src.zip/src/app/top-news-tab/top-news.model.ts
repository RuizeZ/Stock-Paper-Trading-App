export class TopNews {
    logo !: string
    title !: string
    source !: string
    date !: string
    description !: string
    URL !: string
    constructor(currNews: any) {
        this.title = currNews["headline"];
        this.logo = currNews["image"];
        this.source = currNews["source"];
        this.date = this.getTime(currNews["datetime"]);
        this.description = currNews["summary"];
        this.URL = currNews["url"];
    }
    getTime(t: number): string {
        var date = new Date(t * 1000);
        var months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
        var ret = months[date.getMonth()] + ' ' + String(date.getDate()) + ', ' + date.getFullYear();
        return ret;
    }
}