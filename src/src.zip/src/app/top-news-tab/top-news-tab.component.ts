import { Component, OnInit, Input } from '@angular/core';
import { TopNews } from './top-news.model';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-top-news-tab',
  templateUrl: './top-news-tab.component.html',
  styleUrls: ['./top-news-tab.component.css']
})
export class TopNewsTabComponent implements OnInit {
  @Input() searchData!: any;
  validNewsArr: any[] = [];
  newsIndex: any = 0;
  nums !: any[];
  modalNews !: any;
  haveMoreNews: boolean = true;
  closeResult = '';
  constructor(private modalService: NgbModal) { }

  ngOnInit(): void {
    this.createNewArr();
    if (this.validNewsArr.length === 0) {
      this.haveMoreNews = false;
    } else {
      this.nums = Array(Math.floor(this.validNewsArr.length / 2)).fill(0);
    }
    this.newsIndex = 0;
  }
  createNewArr(): void {
    let newsArr = this.searchData['news'];
    let checkArr = ["image", "url", "headline"];
    let index = 0;
    let count = 0;
    let nextNews = false;
    let tempArray = [];
    while (index < newsArr.length && count < 20) {
      nextNews = false;
      let currNews = newsArr[index];
      for (let check of checkArr) {
        if (!(check in currNews) || currNews[check].toString().length === 0) {
          nextNews = true;
          break;
        }
      }
      if (!nextNews) {
        if (tempArray.length == 2) {
          this.validNewsArr.push(tempArray);
          tempArray = [];
        }
        tempArray.push(new TopNews(currNews));
        count++;
      }
      index++;
    }
    this.validNewsArr.push(tempArray);
  }

  openModal(content: any, modalNews: TopNews) {
    this.modalNews = modalNews;
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
}
