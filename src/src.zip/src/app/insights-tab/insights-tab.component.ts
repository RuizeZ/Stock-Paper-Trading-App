import { Component, OnInit, Input } from '@angular/core';
import * as Highcharts from "highcharts";
@Component({
  selector: 'app-insights-tab',
  templateUrl: './insights-tab.component.html',
  styleUrls: ['./insights-tab.component.css']
})
export class InsightsTabComponent implements OnInit {
  @Input() searchData!: any;
  redditTotalMentions: number = 0;
  redditPositive: number = 0;
  redditNegative: number = 0;
  twitterTotalMentions: number = 0;
  twitterPositive: number = 0;
  twitterNegative: number = 0;
  Highcharts: typeof Highcharts = Highcharts;
  EPSChartOptions: Highcharts.Options = {};
  recommendationChartOptions: Highcharts.Options = {};
  actualArr: any[] = [];
  estimateArr: any[] = [];
  xArr: any[] = [];
  xArrR: any[] = [];
  buyArr: any[] = [];
  holdArr: any[] = [];
  sellArr: any[] = [];
  strongBuyArr: any[] = [];
  strongSellArr: any[] = [];


  constructor() { }

  ngOnInit(): void {
    for (let index = 0; index < this.searchData['sentiment']['reddit'].length; index++) {
      this.redditTotalMentions += this.searchData['sentiment']['reddit'][index]['mention'];
      this.redditPositive += this.searchData['sentiment']['reddit'][index]['positiveMention'];
      this.redditNegative += this.searchData['sentiment']['reddit'][index]['negativeMention'];
    }
    for (let index = 0; index < this.searchData['sentiment']['twitter'].length; index++) {
      this.twitterTotalMentions += this.searchData['sentiment']['twitter'][index]['mention'];
      this.twitterPositive += this.searchData['sentiment']['twitter'][index]['positiveMention'];
      this.twitterNegative += this.searchData['sentiment']['twitter'][index]['negativeMention'];
    }
    this.buyArr = [];
    this.holdArr = [];
    this.sellArr = [];
    this.strongBuyArr = [];
    this.strongSellArr = [];
    this.xArrR = [];
    for (let index = 0; index < this.searchData['recommendation'].length; index++) {
      this.buyArr.push(this.searchData['recommendation'][index]['buy']);
      this.holdArr.push(this.searchData['recommendation'][index]['hold']);
      this.sellArr.push(this.searchData['recommendation'][index]['sell']);
      this.strongBuyArr.push(this.searchData['recommendation'][index]['strongBuy']);
      this.strongSellArr.push(this.searchData['recommendation'][index]['strongSell']);
      this.xArrR.push(this.searchData['recommendation'][index]['period'].substring(0, 7));
    }
    // create the recommendation chart
    this.recommendationChartOptions = {
      chart: {
        type: 'column'
      },
      title: {
        text: 'Recommendation Trends'
      },
      yAxis: {
        title: {
          text: '#Analysis'
        }
      },

      xAxis: {
        categories: this.xArrR
      },

      plotOptions: {
        column: {
          stacking: 'normal',
          dataLabels: {
            enabled: true
          }
        }
      },

      series: [{
        type: "column",
        name: 'Strong Buy',
        data: this.strongBuyArr,
      }, {
        type: "column",
        name: 'Buy',
        data: this.buyArr,
      }, {
        type: "column",
        name: 'Hold',
        data: this.holdArr,
      }, {
        type: "column",
        name: 'Sell',
        data: this.sellArr,
      }, {
        type: "column",
        name: 'Strong Sell',
        data: this.strongSellArr
      }]
    }
    // create the EPS chart
    this.actualArr = [];
    this.estimateArr = [];
    this.xArr = [];
    for (let index = 0; index < this.searchData['earnings'].length; index++) {
      if (this.searchData['earnings'][index]['actual'] == null) { this.actualArr.push(0) }
      else { this.actualArr.push(this.searchData['earnings'][index]['actual']) }
      var date = this.searchData['earnings'][index]['period'];
      date = date.substring(0, date.indexOf('T'));
      if (this.searchData['earnings'][index]['estimate'] == null) {
        this.estimateArr.push(0);
        this.xArr.push(date + '\nSurprise: 0');
      }
      else {
        this.estimateArr.push(this.searchData['earnings'][index]['estimate'])
        this.xArr.push(date + '<br/>Surprise: ' + this.searchData['earnings'][index]['estimate']);
      }
    }
    this.EPSChartOptions = {
      title: {
        text: 'Historical EPS Surprises'
      },

      yAxis: {
        title: {
          text: 'Quarterly EPS'
        }
      },

      xAxis: {
        categories: this.xArr
      },

      tooltip: {
        shared: true
      },

      series: [{
        type: "line",
        name: 'Actual',
        data: this.actualArr,
      }, {
        type: "line",
        name: 'Estimate',
        data: this.estimateArr
      }]
    }
  }

}
