import { Component, OnInit } from '@angular/core';
import { GetResultService } from '../get-result.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { FormControl } from '@angular/forms';

@Component({
  selector: 'app-portfolio-page',
  templateUrl: './portfolio-page.component.html',
  styleUrls: ['./portfolio-page.component.css']
})
export class PortfolioPageComponent implements OnInit {
  buyInput = new FormControl('');
  sellInput = new FormControl('');
  currMoney: number = 0;
  companys: any = [];
  emptyList: boolean = false;
  portfolioItem: any;
  closeResult = '';
  currCompany!: any;
  sellCurrTotal: number = 0;
  currTotal: number = 0;
  successBuy: boolean = false;
  successSell: boolean = false;
  companyIndex: number = 0;
  quantity: number = 0;
  alertStr: String = '';
  constructor(private getResultService: GetResultService, private modalService: NgbModal) { }
  async ngOnInit(): Promise<void> {
    this.currMoney = +<any>localStorage.getItem('currMoney');
    this.companys = [];
    this.portfolioItem = JSON.parse(<any>localStorage.getItem('portfolio'));
    if (Object.keys(this.portfolioItem).length === 0) {
      this.emptyList = true;
    } else {
      this.emptyList = false;
      for (let ticker in this.portfolioItem) {
        await this.getResultService.getUpdateResults(ticker);
        this.portfolioItem[ticker]['change'] = +(this.getResultService.searchData['price']['c'] - this.portfolioItem[ticker]['ACS']).toFixed(2);
        this.portfolioItem[ticker]['currPrice'] = +(this.getResultService.searchData['price']['c']).toFixed(2);
        this.portfolioItem[ticker]['marketValue'] = +(this.getResultService.searchData['price']['c'] * this.portfolioItem[ticker]['quantity']).toFixed(2);
        this.companys.push(this.portfolioItem[ticker]);
      }
    }
  }

  openSearch(ticker: any): any {
    this.getResultService.emitChange(ticker);
  }

  openModal(content: any) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
      // manually reset value in the input
      this.resetInput();
    }, (reason) => {
      this.resetInput();
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  resetInput(): void {
    this.sellInput.reset();
    this.buyInput.reset();
    this.currTotal = 0;
    this.sellCurrTotal = 0;
  }

  getcompany(companyIndex: any): void {
    this.currCompany = this.companys[companyIndex];
    this.quantity = this.companys[companyIndex]['quantity'];
    this.companyIndex = companyIndex;
  }

  calculateTotal(): void {
    // string to number use +
    this.currTotal = +((this.buyInput.value * this.currCompany.currPrice).toFixed(2));
    this.sellCurrTotal = +((this.sellInput.value * this.currCompany.currPrice).toFixed(2));
  }

  buyStock(): void {
    this.quantity = this.buyInput.value;
    this.quantity += this.portfolioItem[this.currCompany.ticker]["quantity"];
    var totalCost: number = +(this.currTotal + this.portfolioItem[this.currCompany.ticker]["totalCost"]).toFixed(2);
    var ACS: number = +(totalCost / this.quantity).toFixed(2);
    this.portfolioItem[this.currCompany.ticker]["quantity"] = this.quantity;
    this.portfolioItem[this.currCompany.ticker]["totalCost"] = totalCost;
    this.portfolioItem[this.currCompany.ticker]["marketValue"] = this.quantity * this.portfolioItem[this.currCompany.ticker]["currPrice"];
    this.portfolioItem[this.currCompany.ticker]["ACS"] = ACS;
    this.companys[this.companyIndex] = this.portfolioItem[this.currCompany.ticker];
    localStorage.setItem('portfolio', JSON.stringify(this.portfolioItem));
    this.currMoney = +(this.currMoney - this.currTotal).toFixed(2);
    localStorage.setItem('currMoney', this.currMoney.toString());
    this.alertStr = this.currCompany.ticker;
    this.successBuy = true;
    this.successSell = false;
  }

  sellStock(): void {
    this.quantity -= this.sellInput.value;
    // dont create a new variable
    if (this.quantity === 0) {
      delete this.portfolioItem[this.currCompany.ticker];
      var elements: any = document.getElementById(this.companyIndex.toString());
      elements.remove();
    } else {
      this.portfolioItem[this.currCompany.ticker]['quantity'] = this.quantity;
      this.portfolioItem[this.currCompany.ticker]['totalCost'] = +(this.portfolioItem[this.currCompany.ticker]['totalCost'] - (this.sellInput.value * this.portfolioItem[this.currCompany.ticker]["ACS"])).toFixed(2);
      this.portfolioItem[this.currCompany.ticker]['ACS'] = +(this.portfolioItem[this.currCompany.ticker]['totalCost'] / this.quantity).toFixed(2);
      this.portfolioItem[this.currCompany.ticker]['marketValue'] = this.quantity * this.portfolioItem[this.currCompany.ticker]["currPrice"];
      this.portfolioItem[this.currCompany.ticker]['change'] = (this.portfolioItem[this.currCompany.ticker]["currPrice"] - this.portfolioItem[this.currCompany.ticker]['ACS']).toFixed(2);
      this.companys[this.companyIndex] = this.portfolioItem[this.currCompany.ticker];
    }
    this.currMoney = +(this.currMoney + this.sellCurrTotal).toFixed(2);
    localStorage.setItem('currMoney', this.currMoney.toString());
    localStorage.setItem('portfolio', JSON.stringify(this.portfolioItem));
    this.alertStr = this.currCompany.ticker;
    this.successSell = true;
    this.successBuy = false;
    if (Object.keys(this.portfolioItem).length === 0) {
      this.emptyList = true;
    }
  }

  close(str: String) {
    if (str == 'buy') {
      this.successBuy = false;
    } else if (str == 'sell') {
      this.successSell = false;
    }
  }
}
