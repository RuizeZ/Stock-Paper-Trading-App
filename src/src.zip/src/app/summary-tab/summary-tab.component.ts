import { Component, OnInit, Input, OnChanges, SimpleChanges } from '@angular/core';
import { GetResultService } from '../get-result.service';
import * as Highcharts from 'highcharts/highstock';


@Component({
  selector: 'app-summary-tab',
  templateUrl: './summary-tab.component.html',
  styleUrls: ['./summary-tab.component.css']
})
export class SummaryTabComponent implements OnInit, OnChanges {
  @Input() searchData!: any;
  peers!: string[];
  IPO!: string;
  chartDate!: number[]
  chartPrice!: number[]
  priceArr: any[] = []
  Highcharts: typeof Highcharts = Highcharts;
  chartColor !: string;
  chartConstructor: string = 'chart';
  chartOptions: Highcharts.Options = {};
  constructor(private getResultService: GetResultService) {
  }
  // assign value in ngOnInit
  ngOnInit(): void {  }

  ngOnChanges(changes: SimpleChanges): void {
    if (typeof (this.searchData['peers']) != 'undefined') { this.peers = this.searchData['peers']; }
    this.IPO = this.searchData['company']['ipo'];
    this.IPO = this.IPO.substring(0, this.IPO.indexOf('T'));
    if (this.searchData['history']['s'] != 'no_data') {
      // create the chart
      this.priceArr = []; //reinit the array, otherwise it will contain prevdata
      if (Number(this.searchData['price']['d']) < 0) { this.chartColor = '#FF0000' }
      else { this.chartColor = '#00FF00' }
      this.chartDate = this.searchData['history']['t'];
      this.chartPrice = this.searchData['history']['c'];
      for (let i = 0; i < this.chartDate.length; i++) {
        this.priceArr.push([this.chartDate[i] * 1000, this.chartPrice[i]]);
      }
      this.chartOptions = {};
      this.chartOptions = {
        plotOptions: {
          series: {
            color: this.chartColor
          }
        },
        // disable zoom
        rangeSelector: {
          buttons: [],
          inputEnabled: false
        },
        // disable sliding window
        navigator: {
          enabled: false
        },
        title: {
          text: this.searchData['company']['ticker'] + ' Hourly Price Variation'
        },
        // use local time
        time: {
          useUTC: false
        },
        series: [
          {
            type: "line",
            name: this.searchData['company']['ticker'],
            data: this.priceArr
          }
        ]
      }
    }
  }


  async searchNewData(name: string): Promise<void> {
    this.getResultService.emitChange(name);
  }
}
