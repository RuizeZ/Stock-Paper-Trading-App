import { Component, OnInit } from '@angular/core';
import { GetResultService } from '../get-result.service';
import { map, Subscription, timer } from 'rxjs';
@Component({
  selector: 'app-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.css']
})
export class SearchResultsComponent implements OnInit {
  searchData !: any;
  timerSubscription!: Subscription;
  constructor(private getResultService: GetResultService) {
    // currently in search
    this.getResultService.inOtherTab = false;
    if (this.getResultService.backToSearch) {
      this.searchData = this.getResultService.prevSearchData;
      // set the prevSearchData as the current SeatchData
      this.getResultService.searchData = this.getResultService.prevSearchData;
      this.getResultService.backToSearch = false;
    } else {
      this.searchData = this.getResultService.searchData;
    }
  }
  ngOnInit(): void {
    // timer(15000, 10000) call the function immediately and every 15 seconds
    if (Object.keys(this.getResultService.searchData['company']).length != 0) {
      this.timerSubscription = timer(15000, 15000).pipe(
        map(async () => {
          if (Object.keys(this.getResultService.searchData['company']).length != 0) {
            await this.getResultService.getUpdateResults(this.getResultService.ticker);
            this.searchData = this.getResultService.searchData;
          } else {
            this.timerSubscription.unsubscribe();
          }
        })
      ).subscribe();
    } else {
      this.timerSubscription.unsubscribe();
    }
  }

  checkOpen(isOpen: boolean) {
    if (!isOpen) {
      // make the timer stop when market is close
      this.timerSubscription.unsubscribe();
    }
  }
  ngOnDestroy(): void {
    this.timerSubscription.unsubscribe();
  }
}
