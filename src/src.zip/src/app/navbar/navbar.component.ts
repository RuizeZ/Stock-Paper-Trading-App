import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GetResultService } from '../get-result.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent implements OnInit {
  currTicker!: any;
  public isMenuCollapsed = true;
  constructor(public router: Router, private getResultService: GetResultService) { }

  ngOnInit(): void { }
  openWatchlist(): void {
    // save the current search
    this.getResultService.setPrevSearchData();
    this.router.navigate(["watchlist"]);
  }
  openSearch(str: String): void {
    // if the ticker is invalid, redirect to home page
    if (str === 'home' || this.getResultService.ticker === undefined || Object.keys(this.getResultService.searchData['company']).length === 0) {
      this.currTicker = "home"
      this.getResultService.ticker = undefined;
      this.getResultService.inOtherTab = false;
    } else {
      this.currTicker = this.getResultService.ticker;
    }
    // inOtherTab is the tab that currently at.
    this.getResultService.backToSearch = this.getResultService.inOtherTab;
    this.getResultService.inOtherTab = false;
    this.router.navigate(["search/" + this.currTicker]);
  }

  openProtfolio(): void {
    // save the current search
    this.getResultService.setPrevSearchData();
    this.router.navigate(["portfolio"]);
  }

}
