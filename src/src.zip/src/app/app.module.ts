import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NavbarComponent } from './navbar/navbar.component';
import { SearchBarComponent } from './search-bar/search-bar.component';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AutoItemComponent } from './auto-item/auto-item.component';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { RouterModule } from '@angular/router';
import { SearchResultsComponent } from './search-results/search-results.component';
import { MainPageComponent } from './main-page/main-page.component';
import { CommService } from './comm.service';
import { GetResultService } from './get-result.service';
import { SearchHeaderComponent } from './search-header/search-header.component';
import { SearchBodyComponent } from './search-body/search-body.component'
import { MatTabsModule } from '@angular/material/tabs';
import { SummaryTabComponent } from './summary-tab/summary-tab.component';
import { HighchartsChartModule } from 'highcharts-angular';
import { ChartsTabComponent } from './charts-tab/charts-tab.component';
import { TopNewsTabComponent } from './top-news-tab/top-news-tab.component';
import { InsightsTabComponent } from './insights-tab/insights-tab.component';
import { WatchlistPageComponent } from './watchlist-page/watchlist-page.component';
import { PortfolioPageComponent } from './portfolio-page/portfolio-page.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    SearchBarComponent,
    AutoItemComponent,
    SearchResultsComponent,
    MainPageComponent,
    SearchHeaderComponent,
    SearchBodyComponent,
    SummaryTabComponent,
    ChartsTabComponent,
    TopNewsTabComponent,
    InsightsTabComponent,
    WatchlistPageComponent,
    PortfolioPageComponent
  ],
  imports: [
    BrowserModule,
    NgbModule,
    BrowserAnimationsModule,
    MatAutocompleteModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    MatInputModule,
    MatProgressSpinnerModule,
    MatTabsModule,
    HighchartsChartModule,
    RouterModule.forRoot([
      { path: '', redirectTo: 'search/home', pathMatch: 'prefix' },
      { path: 'search/:ticker', component: MainPageComponent },
      { path: 'watchlist', component: WatchlistPageComponent },
      { path: 'portfolio', component: PortfolioPageComponent }
    ]),
  ],
  providers: [CommService, GetResultService],
  bootstrap: [AppComponent]
})
export class AppModule { }
