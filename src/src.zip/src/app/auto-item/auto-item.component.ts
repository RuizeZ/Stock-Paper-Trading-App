import { Component, OnInit, Input} from '@angular/core';

@Component({
  selector: 'app-auto-item',
  templateUrl: './auto-item.component.html',
  styleUrls: ['./auto-item.component.css']
})
export class AutoItemComponent implements OnInit {
  @Input() autoCompany!: string[];

  constructor() { }

  ngOnInit(): void {
  }

}
