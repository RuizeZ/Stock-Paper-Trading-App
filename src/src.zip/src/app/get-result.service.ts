// this service send http request for search results page in <app-search-results>
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GetResultService {
  searchData !: any;
  prevSearchData !: any;
  ticker !: any;
  emitChangeSource = new Subject<any>();
  numberOfsubscribe: number = 0;
  backToSearch: boolean = false;
  inOtherTab: boolean = false;
  // isOpen = false;


  constructor(private http: HttpClient) { }

  getSearchResults(): any {
    // await func needs to return promise
    return new Promise<void>((resolve, reject) => {
      this.http.get('/search/company/' + this.ticker).subscribe((ret) => {
        this.searchData = JSON.parse(JSON.stringify(ret));
        // this.getStatus();
        resolve();
      });
    });
  }
  getUpdateResults(ticker: string): any {
    // await func needs to return promise
    return new Promise<void>((resolve, reject) => {
      this.http.get('/search/update/' + ticker).subscribe((ret) => {
        this.searchData = JSON.parse(JSON.stringify(ret));
        // this.getStatus();
        resolve();
      });
    });
  }

  setPrevSearchData(): void {
    // from Search to otherTab
    if (!this.inOtherTab) {
      this.inOtherTab = true;
      this.prevSearchData = this.searchData;
    }
    // already in otherTab, do nothing

  }
  setTicker(ticker: string): void {
    this.ticker = ticker;
  }
  emitChange(name: string) {
    this.emitChangeSource.next(name);
  }
  // getStatus() {
  //   var date = new Date();
  //   var resultDate = new Date(this.searchData["price"]['t'] * 1000);
  //   if ((date.getUTCHours() === 13 && date.getUTCMinutes() < 30) || date.getUTCHours() < 13 || date.getUTCHours() >= 20 || resultDate.getDate != date.getDate) {
  //     this.isOpen = false;
  //   } else {
  //     this.isOpen = true;
  //   }
  // }

}
