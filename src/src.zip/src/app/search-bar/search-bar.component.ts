import { Component, OnInit, ViewChild, ElementRef, Output, EventEmitter } from '@angular/core';
import { FormControl } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { GetResultService } from '../get-result.service';
import { MatAutocompleteTrigger } from '@angular/material/autocomplete';


@Component({
  selector: 'app-search-bar',
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.css']
})
export class SearchBarComponent implements OnInit {
  // create the control
  ticker = new FormControl('');
  @Output() isInvalid = new EventEmitter<boolean>();
  @ViewChild(MatAutocompleteTrigger) autocompleteTrigger!: MatAutocompleteTrigger;
  options: any[] = [];
  data !: any;
  searchData !: any;
  autoArr!: Object;
  loading: boolean = true;
  finding: boolean = false;
  isEmpty: boolean = false;
  prevValue !: string;
  isError = false;
  isAutocomplete = true;
  errorType = 'danger';
  // get emelemt in the HTML
  @ViewChild('inputElement') inputElement!: ElementRef;


  constructor(private http: HttpClient, public router: Router, private getResultService: GetResultService) {
    // listen to the service, if change, update the this.searchData
    // one subscribe will be made for each constructor, keep numberOfsubscribe === 0, make sure there is only one subscribe
    if (this.getResultService.numberOfsubscribe === 0) {
      this.getResultService.emitChangeSource.subscribe(data => {
        this.onSubmit(data);
      })
      this.getResultService.numberOfsubscribe++;
    }
    this.router.onSameUrlNavigation = 'reload';
    this.router.routeReuseStrategy.shouldReuseRoute = () => false;
  }
  ngOnInit() {
    if (this.getResultService.ticker === undefined || Object.keys(this.getResultService.searchData['company']).length === 0) {
      this.ticker.setValue('')
    } else {
      this.ticker.setValue(this.getResultService.ticker)
    }
  }
  // get company info
  async onSubmit(value: string): Promise<void> {
    this.finding = true;
    this.loading = false;
    this.autocompleteTrigger.closePanel();
    this.inputElement.nativeElement.value = value;
    if (value.length === 0) {
      this.isEmpty = true;
      this.finding = false;

    } else if (value.includes('.')) {
      this.finding = false;
      this.isError = true;
    }
    else {
      // set the ticker to value, this is the only place to change a ticker
      if (value != this.getResultService.ticker) {
        this.getResultService.setTicker(value);
      }
      await this.getResultService.getSearchResults();
      this.searchData = this.getResultService.searchData;
      // if this.searchData is invalid, this.searchData['company'] doesnt have any key
      if (Object.keys(this.searchData['company']).length === 0) {
        this.isError = true;
        this.finding = false;
        this.isInvalid.emit(this.isError);
      }
      else {
        // reload component on same URL
        this.isError = false;
        this.isInvalid.emit(this.isError);
        this.finding = false;
        this.router.navigate(["search/" + value]);
      }
    }
  }
  // get autocomplete content
  makeRequest(value: string): void {
    if (this.prevValue != value) {
      this.prevValue = value;
      this.options = [];
      if (value.length != 0 && value === this.ticker.value) {
        this.options = [''];
        this.loading = true;
        this.http.get('/search/auto/' + value).subscribe((ret) => {
          this.data = JSON.parse(JSON.stringify(ret));
          if (this.data === undefined) {
            this.loading = false;
          }
          else if (value === this.ticker.value) {
            this.createOptions();
          }
        });
      }
    }

  }
  // parse the auto result to create options
  createOptions() {
    let tempOptions: any[] = [];
    for (let i = 0; i < this.data.result.length; i++) {
      let currentCompany = this.data.result[i];
      if (currentCompany.type.localeCompare("Common Stock") === 0 && !currentCompany.symbol.includes(".")) {
        let oneCompany: string[];
        oneCompany = [currentCompany.symbol, currentCompany.description];
        tempOptions.push(oneCompany);
      }
    }
    this.options = tempOptions;
    this.loading = false;
  }

  close() {
    this.isEmpty = false;
  }

  clearButton() {
    this.getResultService.ticker = undefined;
    this.getResultService.inOtherTab = false;
    this.router.navigate(["search/home"]);
  }
}

