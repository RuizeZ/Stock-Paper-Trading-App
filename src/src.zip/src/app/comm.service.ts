import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CommService {
  searchData !: any;
  constructor() { }
  setResult(result: any){
    this.searchData = result;
  }
  getResult(){
    return this.searchData;
  }
}
