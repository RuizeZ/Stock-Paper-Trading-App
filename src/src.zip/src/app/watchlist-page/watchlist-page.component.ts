import { Component, OnInit } from '@angular/core';
import { GetResultService } from '../get-result.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-watchlist-page',
  templateUrl: './watchlist-page.component.html',
  styleUrls: ['./watchlist-page.component.css']
})
export class WatchlistPageComponent implements OnInit {
  companys: any = [];
  show: boolean = true;
  emptyList: boolean = false;
  watchListItem: any;
  constructor(private getResultService: GetResultService, public router: Router) { }
  async ngOnInit(): Promise<void> {
    this.companys = [];
    this.watchListItem = JSON.parse(<any>localStorage.getItem('watchList'));
    if (Object.keys(this.watchListItem).length === 0) {
      this.emptyList = true;
    } else {
      this.emptyList = false;
      for (let ticker in this.watchListItem) {
        await this.getResultService.getUpdateResults(ticker);
        this.watchListItem[ticker]['lastPrice'] = this.getResultService.searchData['price']['c'].toFixed(2);
        this.watchListItem[ticker]['change'] = this.getResultService.searchData['price']['d'].toFixed(2);
        this.watchListItem[ticker]['changePercentage'] = this.getResultService.searchData['price']['dp'].toFixed(2) + '%';
        this.companys.push(this.watchListItem[ticker]);
      }
    }
  }
  openSearch(ticker: any): any {
    this.getResultService.emitChange(ticker);
  }
  removeTicker(ticker: any, inedx: number): any {
    var elements: any = document.getElementById(inedx.toString());
    elements.remove();
    delete this.watchListItem[ticker];
    localStorage.setItem('watchList', JSON.stringify(this.watchListItem));
    if (Object.keys(this.watchListItem).length === 0) {
      this.emptyList = true;
    }
  }
}
