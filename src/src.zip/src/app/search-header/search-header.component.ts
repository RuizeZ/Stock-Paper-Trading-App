import { Component, Input, OnChanges, OnInit, Output, SimpleChanges, EventEmitter } from '@angular/core';
import { SearchHeader } from './search-header.model';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { FormControl } from '@angular/forms';
@Component({
  selector: 'app-search-header',
  templateUrl: './search-header.component.html',
  styleUrls: ['./search-header.component.css']
})
export class SearchHeaderComponent implements OnInit, OnChanges {
  @Input() searchData!: any;
  @Output() isOpen = new EventEmitter<boolean>();
  buyInput = new FormControl('');
  sellInput = new FormControl('');
  showSuccess: boolean = false;
  showDanger: boolean = false;
  searchHeader: SearchHeader = new SearchHeader();
  alertMessage!: string;
  closeResult = '';
  currTotal: number = 0;
  sellCurrTotal: number = 0;
  tooMuch: boolean = false;
  successBuy: boolean = false;
  successSell: boolean = false;
  currMoney: number = 0;
  constructor(private modalService: NgbModal) {
    
  }
  ngOnInit(): void { }
  ngOnChanges(changes: SimpleChanges): void {
    this.searchHeader.update(this.searchData);
    this.isOpen.emit(this.searchHeader.isOpen);
    this.showSuccess = false;
    this.showDanger = false;
    this.currMoney = +<any>localStorage.getItem('currMoney');
  }

  saveTicker(): void {
    var watchListItem = JSON.parse(<any>localStorage.getItem('watchList'));
    if (this.searchHeader.inWatchList) {
      delete watchListItem[this.searchHeader.ticker];
      localStorage.setItem('watchList', JSON.stringify(watchListItem));
      this.searchHeader.inWatchList = false;
      this.showDanger = true;
    } else {
      watchListItem[this.searchHeader.ticker] = {
        "ticker": this.searchHeader.ticker,
        "companyName": this.searchHeader.companyName,
      };
      this.searchHeader.inWatchList = true;
      this.showSuccess = true;
    }
    localStorage.setItem('watchList', JSON.stringify(watchListItem));
  }
  openModal(content: any) {
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
      this.resetInput();
    }, (reason) => {
      this.resetInput();
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }

  resetInput(): void {
    this.sellInput.reset();
    this.buyInput.reset();
    this.currTotal = 0;
    this.sellCurrTotal = 0;
  }

  buyStock(): void {
    this.successBuy = true;
    this.searchHeader.inportfolio = true;
    this.searchHeader.quantity += this.buyInput.value;
    var portfolioItem = JSON.parse(<any>localStorage.getItem('portfolio'));
    var quantity: number = this.buyInput.value;
    var totalCost: number = +((this.buyInput.value * <any>this.searchHeader.lastPrice).toFixed(2));
    var ACS: number = +(totalCost / quantity).toFixed(2);
    // first company in the portfolio
    if (portfolioItem[this.searchHeader.ticker] != undefined) {
      quantity += portfolioItem[this.searchHeader.ticker]["quantity"];
      totalCost += portfolioItem[this.searchHeader.ticker]["totalCost"];
      ACS = +(totalCost / quantity).toFixed(2);
    }
    portfolioItem[this.searchHeader.ticker] = {
      "ticker": this.searchHeader.ticker,
      "companyName": this.searchHeader.companyName,
      "quantity": quantity,
      "totalCost": totalCost,
      "ACS": ACS,
    };
    localStorage.setItem('portfolio', JSON.stringify(portfolioItem));
    this.currMoney = +(this.currMoney - this.currTotal).toFixed(2);
    localStorage.setItem('currMoney', this.currMoney.toString());
  }
  sellStock(): void {
    this.successSell = true;
    this.searchHeader.quantity -= this.sellInput.value;
    var portfolioItem = JSON.parse(<any>localStorage.getItem('portfolio'));
    var quantity = this.searchHeader.quantity;
    if (this.searchHeader.quantity === 0) {
      this.searchHeader.inportfolio = false;
      delete portfolioItem[this.searchHeader.ticker];
    } else {
      portfolioItem[this.searchHeader.ticker]['quantity'] = quantity;
      portfolioItem[this.searchHeader.ticker]['totalCost'] = +(portfolioItem[this.searchHeader.ticker]['totalCost'] - (this.sellInput.value * portfolioItem[this.searchHeader.ticker]["ACS"])).toFixed(2);
      portfolioItem[this.searchHeader.ticker]['ACS'] = +(portfolioItem[this.searchHeader.ticker]['totalCost'] / quantity).toFixed(2);
    }
    this.currMoney = +(this.currMoney + this.sellCurrTotal).toFixed(2);
    localStorage.setItem('currMoney', this.currMoney.toString());
    localStorage.setItem('portfolio', JSON.stringify(portfolioItem));
  }
  calculateTotal(): void {
    // string to number use +
    this.currTotal = +((this.buyInput.value * <any>this.searchHeader.lastPrice).toFixed(2));
    this.sellCurrTotal = +((this.sellInput.value * <any>this.searchHeader.lastPrice).toFixed(2));
  }
  close(str: String) {
    if (str == 'buy') {
      this.successBuy = false;
    } else if (str == 'sell') {
      this.successSell = false;
    }
    else if (str == 'add') {
      this.showSuccess = false;
    }
    else if (str == 'remove') {
      this.showDanger = false;
    }
  }
}
