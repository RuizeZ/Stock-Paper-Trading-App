export class SearchHeader {
    ticker!: string
    companyName!: string
    exchangeCode!: string
    lastPrice!: string
    change!: string
    changePercentage!: string
    logo !: string
    currentTimestamp!: string
    marketStatus!: string
    isOpen: boolean = true;
    inWatchList: boolean = false;
    inportfolio: boolean = false;
    quantity: number = 0;
    constructor() { }
    getTime(t: number): string {
        var date = new Date();
        var resultDate = new Date(t * 1000);
        var ret = date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0') + '-' + String(date.getDate()).padStart(2, '0') + ' ' + String(date.getHours()).padStart(2, '0') + ':' + String(date.getMinutes()).padStart(2, '0') + ':' + String(date.getSeconds()).padStart(2, '0');
        if ((date.getUTCHours() === 13 && date.getUTCMinutes() < 30) || date.getUTCHours() < 13 || date.getUTCHours() >= 20 || resultDate.getDate() != date.getDate()) {
            date = new Date(t * 1000);
            var closeTime = date.getFullYear() + '-' + String(date.getMonth() + 1).padStart(2, '0') + '-' + String(date.getDate()).padStart(2, '0') + ' ' + String(date.getHours()).padStart(2, '0') + ':' + String(date.getMinutes()).padStart(2, '0') + ':' + String(date.getSeconds()).padStart(2, '0');
            this.marketStatus = 'Market Colsed on ' + closeTime;
            this.isOpen = false;
        } else {
            this.marketStatus = 'Market is Open';
            this.isOpen = true;
        }
        return ret;
    }
    update(searchData: any): void {
        this.ticker = searchData["company"]['ticker'];
        this.companyName = searchData["company"]['name'];
        this.exchangeCode = searchData["company"]['exchange'];
        this.logo = searchData["company"]['logo'];
        this.lastPrice = Number(searchData["price"]['c']).toFixed(2);
        this.change = Number(searchData["price"]['d']).toFixed(2);
        this.changePercentage = Number(searchData["price"]['dp']).toFixed(2) + '%';
        searchData["price"]['dp'];
        this.currentTimestamp = this.getTime(searchData["price"]['t']);
        var watchListItem = JSON.parse(<any>localStorage.getItem('watchList'));
        if (watchListItem.hasOwnProperty(this.ticker)) {
            this.inWatchList = true;
        } else {
            this.inWatchList = false;
        }
        var portfolioItem = JSON.parse(<any>localStorage.getItem('portfolio'));
        if (portfolioItem.hasOwnProperty(this.ticker)) {
            this.quantity = portfolioItem[this.ticker]['quantity'];
            this.inportfolio = true;
        } else {
            this.inportfolio = false;
        }

    }
}