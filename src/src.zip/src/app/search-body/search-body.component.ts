import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-search-body',
  templateUrl: './search-body.component.html',
  styleUrls: ['./search-body.component.css']
})
export class SearchBodyComponent implements OnInit {
  @Input() searchData!: any;
  constructor() {
  }

  ngOnInit(): void {

  }
}
