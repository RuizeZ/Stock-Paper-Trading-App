import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router'

@Component({
  selector: 'app-main-page',
  templateUrl: './main-page.component.html',
  styleUrls: ['./main-page.component.css']
})
export class MainPageComponent implements OnInit {
  ticker!: any;
  isInvalid: boolean = false;
  constructor(private route: ActivatedRoute, private router: Router) {

  }

  ngOnInit(): void {
    this.ticker = this.route.snapshot.paramMap.get('ticker')
    if (localStorage.getItem('currMoney') === null) {
      localStorage.setItem('currMoney', '25000');
    }
    if (localStorage.getItem('watchList') === null) {
      localStorage.setItem('watchList', '{}');
    }
    if (localStorage.getItem('portfolio') === null) {
      localStorage.setItem('portfolio', '{}');
    }
    // this.router.navigate(["search/home"]);
  }
  checkValid(isInvalid: boolean): void {
    this.isInvalid = isInvalid;
  }
}
